import {
 Controller


} from '../../../lib/pxp';
import {
  Get,
  Route,
  Post,
  Patch,
  Delete,
  StoredProcedure,
  DbSettings,
  ReadOnly,
  Model,
  Authentication
} from '../../../lib/pxp/Decorators';
import {getManager} from 'typeorm';
import LocationModel from '../entity/Location';
import _ from 'lodash';
@Route('/locations')
@Model('portal-nd/Package')
class Location extends Controller {
  @Get('/:locationId')
  @DbSettings('Orm')
  @ReadOnly(true) 
  @Authentication(false)
  async find(params: Record<string, unknown>): Promise<any> {
    console.log(params);
    
    const locationId = params.locationId;
    const data  = await getManager().findOne(LocationModel, {
    	where: {
            locationId
        },
        relations: ['vendors']
    });
    
    const logo = _.find(data?.vendors, {assetType: 'PORTAL_COMPANY_LOGO'});
    const background = _.find(data?.vendors, {assetType: 'PORTAL_BACKGROUND_IMAGE'});
    
    return {
      locationId: data?.locationId,
      state: data?.state,
      timezone: data?.timezone,
      logo: logo?.assetValue,
      background: background?.assetValue
    };
  }
}

export default Location;
