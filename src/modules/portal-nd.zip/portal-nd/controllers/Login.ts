import { Controller } from '../../../lib/pxp';
import {
  Get,
  DbSettings,
  ReadOnly,
  Model,
  Authentication,
  Post,
  Route
} from '../../../lib/pxp/Decorators';
import {getManager} from 'typeorm';
import { customFirebaseInitialize, configPassportFirebase } from '../../../auth/config/passport-firebase';
import LocationModel from '../entity/Location';
import firebase from 'firebase';
import adminF from 'firebase-admin';
import fs from 'fs';
import path from 'path';
import * as _ from 'lodash';
@Route('/login')
class Login extends Controller {
  @Authentication(false)
  @Get('/')
  @ReadOnly(true)
  @DbSettings('Orm')
  async login(params: Record<string, unknown>): Promise<any> {
    const locationId = params.locationId;
    const username: string = String(params.username);
    const password: string = String(params.password);

    // configPassportFirebase(credentials.project_id, credentials.auth_uri, 'http://localhost:3000/api/portal-nd/login/callback');
    // console.log('AUTH ', passport.authenticate('firebaseauth', {}));
    
    const firebaseConfig = {
      apiKey: "AIzaSyALxfEr_f0c6rtE8iyoJGG10qDQUUEqqcU",
      authDomain: "feroce-fitness-18b92.firebaseapp.com",
      databaseURL: "https://feroce-fitness-18b92.firebaseio.com",
      projectId: "feroce-fitness-18b92",
      storageBucket: "feroce-fitness-18b92.appspot.com",
      messagingSenderId: "155686789108",
      appId: "1:155686789108:web:56a4e9d1bc116122a023a1",
      measurementId: "G-N7M3SGLJ19"
    };

    firebase.initializeApp(firebaseConfig);
    const resp: any = await firebase.auth().signInWithEmailAndPassword( username, password);
    
    return {
      uid: resp.user.uid,
      email: resp.user.email,
      displayName: resp.user.displayName,
      photoURL: resp.user.photoURL,
      emailVerified: resp.user.emailVerified,
    }    
  }

  @Authentication(false)
  @Get('/admin/users')
  @ReadOnly(true)
  @DbSettings('Orm')
  async adminUsers(params: Record<string, unknown>): Promise<any> {
    const locationId = params.locationId;

    const location: any = await getManager().findOne(LocationModel, {
      where: {
        locationId,
      },
      select: ['firebaseJson', 'firebaseUrl']
    });

    const pathCredentials = path.join(__dirname ,'../firebase/' , location.firebaseJson);

    if (fs.existsSync(pathCredentials)) {
      const firebaseUrl = location?.firebaseUrl;
      const credentials: any =  await import(pathCredentials);
      let admin: any;
    
      if(_.find(adminF.apps, {name_: credentials.project_id})) {
        admin = _.find(adminF.apps, {name_: credentials.project_id});
      } else {
        admin = customFirebaseInitialize(credentials, firebaseUrl, credentials.project_id);
      }

      // const  isLogin = await admin.auth().getUserByEmail('israel@kplian.com')
      //   .then((userRecord:any) => {
      //     console.log(userRecord, `Successfully fetched`);
      //   }, (err:any) => console.log('ERROR ', err));
      const db = admin.database();  
      const ref: any = db.ref("/users");
      // await ref.once("value", function(snapshot: { val: () => any; }) {
      //   console.log(snapshot.val());
      // });

      let users:any = await admin.auth().listUsers(10);
      return users;
    } else {
      return {
        error: true,
        message: 'Location invalid'
      };
    }
    
  }
}

export default Login;