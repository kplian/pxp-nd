import {
  Controller,
  Route,
  Model,
  Authentication
} from '../../../lib/pxp';
import { Get, DbSettings, ReadOnly } from '../../../lib/pxp/Decorators';
import {getManager} from 'typeorm';
import PackageModel from '../entity/Package';

@Route('/packages')
@Model('portal-nd/Package')
class Package extends Controller {
    @Get('/location/:locationId')
    @DbSettings('Orm')
    @ReadOnly(true)
    @Authentication(false)
    async findByLocationId(params: Record<string, unknown>): Promise<any> {
      const locationId = params.locationId;
      const data  = await getManager().find(PackageModel, {
    	  where: {
            locationId,
            isDelete: 0,
            availableOnline: 'Y',
        },
      });
      return data;
    }
}

export default Package;
