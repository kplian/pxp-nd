import { OneToMany, JoinColumn, BaseEntity, Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
import VendorLocationAssets from './VendorLocationAssets';

@Entity({ name: 'location' })
export default class Location extends BaseEntity{
  @PrimaryGeneratedColumn({ name: 'location_id' })
  locationId: number;

  @Column({ name:'location_name', type: 'varchar', length: 100, nullable: false })
  locationName: string;

  @Column({ name: 'vendor_id', type: 'int'})
  vendorId: number;

  @Column({ name:'location_address1', type: 'varchar', length: 100, nullable: false })
  locationAddress1: string;

  @Column({ name:'location_address2', type: 'varchar', length: 100, nullable: false })
  locationAddress2: string;

  @Column({ name:'city', type: 'varchar', length: 100, nullable: false })
  city: string;

  @Column({ name:'state', type: 'varchar', length: 255, nullable: false })
  state: string;

  @Column({ name:'county', type: 'varchar', length: 255, nullable: false })
  county: string;

  @Column({ name:'country', type: 'varchar', length: 255, nullable: false })
  country: string;

  @Column({ name:'postal_code', type: 'varchar', length: 100, nullable: false })
  postalCode: string;

  @Column({ name:'mobile_number', type: 'varchar', length: 100, nullable: false })
  mobileNumber: string;

  @Column({ name:'work_number', type: 'varchar', length: 100, nullable: false })
  workNumber: string;

  @Column({ name:'timezone', type: 'int', nullable: false })
  timezone: number;

  @Column({ name:'date_created', type: 'timestamp', nullable: false })
  dateCreated: Date;

  @Column({ name:'active', type: 'varchar', length: 1, nullable: false })
  active: string;

  @Column({ name:'IS_DELETE', type: 'int', nullable: false })
  isDelete: number;

  @Column({ name:'CREATED_BY', type: 'varchar', length: 100, nullable: false })
  createdBy: string;

  @Column({ name:'master_location', type: 'varchar', length: 1 })
  masterLocation: string;

  @Column({ name:'bundle_app_identifier', type: 'varchar', length: 100 })
  bundleAppIdentifier: string;

  @Column({ name:'firebase_json', type: 'varchar', length: 100 })
  firebaseJson: string;

  @Column({ name:'firebase_url', type: 'varchar', length: 200 })
  firebaseUrl: string;

  @Column({ name:'firebase_url_cf', type: 'varchar', length: 200 })
  firebaseUrlCf: string;

  @Column({ name:'bulk_update', type: 'varchar', length: 1, nullable: false })
  bulkUpdate: string;



  @OneToMany(() => VendorLocationAssets, vla => vla.location)
//  @JoinColumn({ name: 'vendor_id' })
  vendors: VendorLocationAssets[];
}
