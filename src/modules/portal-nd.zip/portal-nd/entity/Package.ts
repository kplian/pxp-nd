import { BaseEntity, Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity({ name: 'package' })
export default class Package extends BaseEntity{
  @PrimaryGeneratedColumn({ name: 'PACKAGE_ID' })
  packageId: number;

  @Column({ name: 'LOCATION_ID', type: 'int'})
  locationId: number;  

  @Column({ name:'PACKAGE_NAME', type: 'varchar', length: 500, nullable: false })
  packageName: string;

  @Column({ name: 'PRICE', type: 'decimal'})
  price: number;
  
  @Column({ name: 'AVAILABLE_ONLINE', type: 'varchar', length: 1})
  availableOnline: string;

  @Column({ name: 'IS_DELETE', type: 'tinyint'})
  isDelete: number;
}
