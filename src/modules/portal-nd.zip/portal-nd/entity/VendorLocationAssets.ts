import { JoinColumn, ManyToOne, OneToMany, BaseEntity, Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
import Location from './Location';

@Entity({ name: 'vendor_location_assets' })
export default class VendorLocationAssets extends BaseEntity{
  @PrimaryGeneratedColumn({ name: 'vla_id' })
  vlaId: number;

  @Column({ name:'asset_value', type: 'varchar', length: 2000, nullable: false })
  assetValue: string;
   
  @Column({ name:'asset_type', type: 'varchar', length: 100, nullable: false })
  assetType: string;

  @ManyToOne((type) => Location, (location) => location.vendors)
  @JoinColumn({ name: 'location_id' })
  location: Location;
}
